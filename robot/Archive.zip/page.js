// jQuery required
const userPhoto = "logo.png";
const chatbox = "#js-chatbox";
const markTimeInterval = 1000 * 60 * 15;
let page = {
    _$userPhoto : userPhoto,
    _$context : chatbox,
    onmessage : function( type,message ){
        let domStr = this._$createChatItem( type,message );
        let timeMarker;
        if(domStr){
            timeMarker = this._$createTimeMarker(message && message["mark"]);
            if( timeMarker ){
                jQuery(this._$context).append(timeMarker);
            }
            jQuery(this._$context).append(domStr);
            this._$scrollToBottom();
        }
    },
    _$scrollToBottom : function(){
        let context = jQuery(this._$context)
        scrollTop = context.outerHeight() - context.parent().outerHeight()
        ;
        if(scrollTop > 0){
            context.parent().scrollTop(scrollTop);
        }
    },
    _$createChatItem : function( type, message ){
        if( type === "client" ){
            return this._$createClientChatItem(message);
        }else if( type === "server" ){
            return this._$createServerChatItem(message);
        }else if( type === "socketError" ){

        }
    },
    _$createServerChatItem : function(message){
        let {data,error,mark} = message;

        let {openid, msg,buttons,state,type,textbox,subtype} = data;
        let result;
        if(type === "nac"){
            result = `<div class="response-block" data-mark="${mark}"><img src="logo.png"><i></i><div class="content temp-1"><p>${msg}</p>`;
            if(state == 0 || state == 1){
                let buttonStr = `<div class="btn-block">`;
                if(buttons.length){
                    buttons.forEach(item => buttonStr += `<b>${item}</b>`);
                    buttonStr += "</div>";
                    result += buttonStr;
                }
                result += "</div></div>";
            }
            if(state == 1){
                this._$storageOpenid(openid);
            }
            if(textbox){
                this._$switchInputbox("login");
            }else{
                this._$switchInputbox();
            }
        }
        this._$showButtons(buttons);
        return result;
    },
    _$storageOpenid : function(id){

        try{
            this[Symbol.for("openid")] = id;
            window.localStorage.setItem("userWxId",id);
        }catch(e){

        }
    },
    _$clearOpenid : function(){

        try{
            delete this[Symbol.for("openid")];
            window.localStorage.removeItem("userWxId");
        }catch(e){

        }
    },
    _$switchInputbox : function(type){
        let hasOpen = !! this[Symbol.for("openid")]
        ,   origintype = this[Symbol.for("inputtype")]
        ,   comm = jQuery("#js-common-toolbar")
        ,   login = jQuery("#js-login-toolbar")
        ,   btn = jQuery("#js-foot-btn-box")
        ,   textarea = jQuery("#js-textarea-toolbar")
        ,   cover = jQuery("#js-cover")
        ;
        if( !type ){
            type === hasOpen ? "common" : undefined;
        }
        if(origintype === type){
            return ;
        }
        this[Symbol.for("inputtype")] = type;
        if(type === "login"){
            comm.addClass("hide");
            btn.addClass("hide");
            textarea.addClass("hide");
            login.removeClass("hide");
            cover.show();
        }else if(type === "textarea"){
            login.addClass("hide");
            comm.addClass("hide");
            btn.addClass("hide");
            textarea.removeClass("hide");
            cover.show();
        }else if(type === "common" ){
            login.addClass("hide");
            textarea.addClass("hide");
            comm.removeClass("hide");
            btn.removeClass("hide");
            cover.hide();
        }else{
            login.addClass("hide");
            comm.addClass("hide");
            btn.addClass("hide");
            textarea.addClass("hide");
            cover.hide();
        }
    },
    _$showButtons : function(buttons){

    },
    _$createClientChatItem : function( message ){
        let { type,mark,msg,username } = message;
        let userPhoto = this._$userPhoto;
        if( type - 10 === 0 ){
            if( username ){
                return `<div class="request-block" data-mark="${mark}"><img src="${userPhoto}"><i></i><div class="content">${username} ******</div></div>`
            }
        } else if( msg ){
            return `<div class="request-block" data-mark="${mark}"><img src="${userPhoto}"><i></i><div class="content">${msg}</div></div>`
        } else {
            return ;
        }
    },
    _$createTimeMarker : function( currentStamp, referStamp){
        if( !currentStamp || ( referStamp && Math.abs(currentStamp - referStamp) < markTimeInterval ) ){
            return;
        }
        if( !referStamp ){
            let prevMarker = this[Symbol.for("prevMarker")];
            this[Symbol.for("prevMarker")] = currentStamp;
            if( prevMarker && Math.abs(currentStamp - prevMarker) < markTimeInterval ){
                return;
            }
        }
        let mark = new Date(currentStamp)
        ,   datenow = new Date
        ,   markArray = [mark.getFullYear(),mark.getMonth() - 0 + 1, mark.getDate()]
        ,   nowArray = [datenow.getFullYear(),datenow.getMonth() - 0 + 1, datenow.getDate()]
        ,   markStr = ""
        ,   hour = mark.getHours()
        ,   minute = mark.getMinutes()
        ;
        markArray.forEach( ( item,key ) => {
            if(markStr.length || item !== nowArray[key]){
                markStr += item + ( key === 0 ? "年" : ( key === 1 ? "月" : "日" ) )
            }
        });
        markStr += (markStr ? " ":"") + ( hour >= 12 ? "下午 " : "上午 " ) + ( hour > 12 ? hour - 12 : hour ) + ":" + ( minute > 9 ? minute : "0" + minute);
        return `<div class="time-mark">${markStr}</div>`
    },
    set message( msg ){
        if( typeof msg === "string" ){
            msg = {msg : msg};
        }
        if( !msg["type"] && this[Symbol.for("type")] ){
            msg["type"] = this[Symbol.for("type")];
        }
        management.receivePageMessage = msg;
    }
}
management.onmessage = function(){
    page.onmessage.apply(page,arguments);
}
